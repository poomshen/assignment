package org.zerock.persistence;

public interface PointDAO {

	public void updatePoint(String uid,int point)throws Exception;
	
}

