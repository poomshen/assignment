package net.madvirus.spring4.chap12.store.dao;

import net.madvirus.spring4.chap12.store.domain.PaymentInfo;

public interface PaymentInfoDao {

	void insert(PaymentInfo paymentInfo);

}
