package net.madvirus.spring4.chap12.store.dao;

import net.madvirus.spring4.chap12.store.domain.PurchaseOrder;

public interface PurchaseOrderDao {

	void insert(PurchaseOrder order);

}
