package net.madvirus.spring4.chap10.springconf;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootConfig {

}
