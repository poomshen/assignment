package net.madvirus.spring4.chap06.board;

public interface WriteArticleService {

	public void write(NewArticleRequest newArticleReq);
}
