package net.madvirus.spring4.chap06.board;

public interface ReadArticleService {

	Article read(Integer id);

}
