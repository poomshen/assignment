package net.madvirus.spring4.chap03;


public class ConnPool3 {

	public void init() {
		System.out.println("ConnPool3.init()");
	}

	public void destroy() {
		System.out.println("ConnPool3.destroy()");
	}
}
