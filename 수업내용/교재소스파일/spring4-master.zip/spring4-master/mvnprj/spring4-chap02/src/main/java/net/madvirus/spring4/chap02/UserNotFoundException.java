package net.madvirus.spring4.chap02;

@SuppressWarnings("serial")
public class UserNotFoundException extends RuntimeException {

}
