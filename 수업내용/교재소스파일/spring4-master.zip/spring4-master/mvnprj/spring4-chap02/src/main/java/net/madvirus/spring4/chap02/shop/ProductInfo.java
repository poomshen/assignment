package net.madvirus.spring4.chap02.shop;

public class ProductInfo {

}
