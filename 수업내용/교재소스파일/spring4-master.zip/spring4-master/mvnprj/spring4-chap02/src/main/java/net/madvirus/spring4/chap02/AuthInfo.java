package net.madvirus.spring4.chap02;

public class AuthInfo {
	private String id;

	public AuthInfo(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}
}
