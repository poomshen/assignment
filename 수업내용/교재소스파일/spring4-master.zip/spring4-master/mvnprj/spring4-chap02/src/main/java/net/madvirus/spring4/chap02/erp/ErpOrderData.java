package net.madvirus.spring4.chap02.erp;

public class ErpOrderData {

}
