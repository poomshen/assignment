package net.madvirus.spring4.chap02.search;

public class SearchDocument {

}
