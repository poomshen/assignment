package net.madvirus.spring4.chap13.store.domain;

public interface PurchaseOrderRepository {

	void save(PurchaseOrder order);

}
