package net.madvirus.spring4.chap05;

public interface ThresholdRequired {

	public void setThreshold(int threshold);
}
