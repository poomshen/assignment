package net.madvirus.spring4.chap14.application;

public interface UpdateTeamService {
	public void udpateName(Long teamId, String newName);
}
