package net.madvirus.spring4.chap14.application;

public interface UpdateEmployeeService {

	public void updateEmployee(UpdateRequest updateReq);
}
