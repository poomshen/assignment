package net.madvirus.spring4.chap01;

import java.util.List;

public interface BuildRunner {

	public void build(List<String> srcDirs, String binDir);

}
